import React, { useEffect, useMemo, useRef, useState } from "react";

// 單檔 React App（可直接預覽）。
// 功能：
// 1) 以自然語言輸入（粵語/中文/英文皆可），AI 解析「日期（支援：上星期四/尋日等）」、「餐別（早餐/午餐/晚餐/小食）」、「營養（熱量、蛋白質、脂肪、碳水）」與項目清單。
// 2) 可選 AI 供應商：OpenAI 官方 / OpenAI 兼容（如 DeepSeek、DeepInfra 等）/ 完全離線估算（Fallback）。
// 3) 內建月曆視圖，按日檢視紀錄與總營養；支援 ICS 匯出到行事曆。
// 4) 本地儲存（localStorage），無伺服器也能用。
// 5) 介面與文案使用繁體中文。

// —— 注意 ——
// • 若要使用 AI 分析，請在「右上角・設定」輸入 API Key、模型等。
// • 若未設定 API，系統會用內建營養表做離線估算（較粗略）。

// 小工具：隨機 ID
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

// —— 型別定義 ——
/** @typedef {"早餐" | "午餐" | "晚餐" | "小食" | "未知"} Meal */

/** @typedef {{
 *  id: string;
 *  text: string;           // 原始輸入
 *  dateISO: string;        // YYYY-MM-DD（以使用者本地時區）
 *  time?: string;          // HH:mm（可選）
 *  meal: Meal;
 *  calories: number;
 *  protein: number;
 *  fat: number;
 *  carbs: number;
 *  items: { name: string; grams?: number; calories?: number; protein?: number; fat?: number; carbs?: number }[];
 *  source: "AI" | "估算";
 *  createdAt: number;      // timestamp
 * }} Entry */

/** @typedef {{
 *  provider: "openai" | "compatible" | "offline";
 *  apiKey?: string;
 *  baseUrl?: string;   // 供 openai 或 compatible 使用
 *  model?: string;     // 供 openai 或 compatible 使用
 *  organization?: string; // OpenAI 可選
 * }} AISettings */

// —— 本地儲存 ——
const LS_ENTRIES = "dietlog.entries.v1";
const LS_SETTINGS = "dietlog.settings.v1";

// —— 離線營養資料（簡表；100g 可食部，熟）——
const FOOD_DB = [
  { keys: ["雞翼", "雞中翼", "雞翼(連皮)"], kcal: 210, p: 27, f: 12, c: 0 },
  { keys: ["雞腿", "雞髀", "雞腿肉"], kcal: 209, p: 26, f: 10, c: 0 },
  { keys: ["雞胸", "雞胸肉"], kcal: 165, p: 31, f: 3.6, c: 0 },
  { keys: ["牛胸", "牛腩", "牛胸肉"], kcal: 250, p: 26, f: 17, c: 0 },
  { keys: ["白飯", "米飯", "飯"], kcal: 130, p: 2.7, f: 0.3, c: 28 },
  { keys: ["麵包", "方包"], kcal: 265, p: 9, f: 3.2, c: 49 },
  { keys: ["雞蛋", "蛋"], kcal: 155, p: 13, f: 11, c: 1.1 }, // 100g；一隻約 50g
  { keys: ["牛扒", "牛排"], kcal: 250, p: 26, f: 17, c: 0 },
  { keys: ["三文魚", "鮭魚"], kcal: 208, p: 20, f: 13, c: 0 },
  { keys: ["意粉", "義大利麵"], kcal: 158, p: 5.8, f: 0.9, c: 31 },
];

function findFoodMacroByName(name) {
  const n = name.toLowerCase();
  for (const row of FOOD_DB) {
    for (const k of row.keys) {
      if (n.includes(k.toLowerCase())) return row;
    }
  }
  return null;
}

// —— 日期工具 ——
const pad = (n) => String(n).padStart(2, "0");
const toDateISO = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

// 解析「上星期四／尋日／前日／今日／聽日」與「YYYY-MM-DD」等；否則傳回 null。
function parseCantoneseDate(text) {
  const now = new Date();
  const t = text.replace(/\\s+/g, "");

  // 絕對日期：YYYY-MM-DD 或 YYYY/MM/DD
  const abs = t.match(/(20\\d{2})[-\\/]?(\\d{1,2})[-\\/]?(\\d{1,2})/);
  if (abs) {
    const y = +abs[1];
    const m = +abs[2] - 1;
    const d = +abs[3];
    const dt = new Date(y, m, d);
    if (!isNaN(dt.getTime())) return dt;
  }

  // 今日／尋日／前日／聽日
  if (/(今日|今天)/.test(t)) return new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (/(尋日|昨天|昨晚)/.test(t)) return new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
  if (/(前日|前天)/.test(t)) return new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2);
  if (/(聽日|明天|明日)/.test(t)) return new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);

  // 上星期X / 上禮拜X / 上個禮拜X
  const wk = t.match(/上(個)?(星(期)?|禮拜)(一|二|三|四|五|六|日|天)/);
  if (wk) {
    const map = { "一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "日": 0, "天": 0 };
    const targetWeekday = map[wk[4]]; // 0=日 ... 6=六
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    // 取上週的 targetWeekday
    const currentWeekday = d.getDay();
    const diffToLastWeek = 7 + currentWeekday - targetWeekday; // 至上一次該星期幾的距離
    d.setDate(d.getDate() - diffToLastWeek);
    return d;
  }

  return null;
}

function guessMeal(text /**: string */) /**: Meal */ {
  const s = text.toLowerCase();
  if (/早餐|早上|morning|breakfast/.test(s)) return "早餐";
  if (/午餐|中午|noon|lunch/.test(s)) return "午餐";
  if (/晚餐|夜晚|dinner|supper|夜宵|宵夜/.test(s)) return "晚餐";
  if (/點心|加餐|零食|snack/.test(s)) return "小食";
  return "未知";
}

function todayISO() { return toDateISO(new Date()); }

// —— AI 請求 ——
async function analyzeWithAI(settings /**: AISettings */, text /**: string */, date /**: Date */) {
  const mealHint = guessMeal(text);
  const dateISO = toDateISO(date);

  // 離線模式：使用簡表 + 粗略份量推估
  if (!settings || settings.provider === "offline" || !settings.apiKey) {
    const items = offlineEstimate(text);
    const totals = items.reduce((a, b) => ({
      calories: a.calories + (b.calories || 0),
      protein: a.protein + (b.protein || 0),
      fat: a.fat + (b.fat || 0),
      carbs: a.carbs + (b.carbs || 0),
    }), { calories: 0, protein: 0, fat: 0, carbs: 0 });
    return {
      meal: mealHint,
      dateISO,
      items,
      totals,
      source: "估算",
    };
  }

  const sysPrompt = `你是一個營養師兼資料抽取器。

任務：將使用者以粵語/中文/英文描述的飲食，解析為結構化 JSON。

要求：
- 必須只輸出 JSON，切勿包含解說。
- 分析餐別（早餐/午餐/晚餐/小食），若無法判斷用"未知"。
- 解析可能出現的相對日期（如：上星期四、尋日、今日）。若指明日期以外，保持為 ${dateISO}。
- 將食物拆成多個 item，包含名稱、估算克數（若可）、以及每項的熱量 kcal、蛋白質 g、脂肪 g、碳水 g。
- 總結總熱量與各宏量營養素。
- 若份量未提及，假設常見食用份量（如：一碗白飯≈160g；一隻雞翼可食部≈35-45g；一隻全蛋≈50g）。
- 若描述語焉不詳，請基於一般常識作保守估算。
- 請用繁體中文餐別名稱（早餐/午餐/晚餐/小食/未知）。
輸出 JSON 結構：
{
  "dateISO": "YYYY-MM-DD",
  "meal": "早餐|午餐|晚餐|小食|未知",
  "items": [{"name":"", "grams":number, "calories":number, "protein":number, "fat":number, "carbs":number}],
  "totals": {"calories":number, "protein":number, "fat":number, "carbs":number}
}`;

  const userPrompt = `請解析：${text}
提示：若文本含相對日期，請落實到實際日期（本地時區）。若未給日期，使用 ${dateISO}。`;

  // 構造 OpenAI 或 OpenAI 兼容 API 請求
  const baseUrl = settings.baseUrl?.replace(/\/$/, "") || "https://api.openai.com/v1";
  const url = `${baseUrl}/chat/completions`;
  const headers = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${settings.apiKey}`,
  };
  if (settings.organization) headers["OpenAI-Organization"] = settings.organization;
  const body = {
    model: settings.model || "gpt-4o-mini",
    messages: [
      { role: "system", content: sysPrompt },
      { role: "user", content: userPrompt },
    ],
    temperature: 0.2,
    response_format: { type: "json_object" },
  };

  try {
    const resp = await fetch(url, { method: "POST", headers, body: JSON.stringify(body) });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    const content = data?.choices?.[0]?.message?.content;
    const parsed = JSON.parse(content);

    // 安全檢查 + 後處理
    const meal = ["早餐","午餐","晚餐","小食","未知"].includes(parsed.meal) ? parsed.meal : (mealHint || "未知");
    const result = {
      meal,
      dateISO: parsed.dateISO || dateISO,
      items: Array.isArray(parsed.items) ? parsed.items : [],
      totals: parsed.totals || { calories: 0, protein: 0, fat: 0, carbs: 0 },
      source: "AI",
    };
    return result;
  } catch (e) {
    console.warn("AI 解析失敗，改用離線估算：", e);
    const items = offlineEstimate(text);
    const totals = items.reduce((a, b) => ({
      calories: a.calories + (b.calories || 0),
      protein: a.protein + (b.protein || 0),
      fat: a.fat + (b.fat || 0),
      carbs: a.carbs + (b.carbs || 0),
    }), { calories: 0, protein: 0, fat: 0, carbs: 0 });
    return { meal: mealHint, dateISO, items, totals, source: "估算" };
  }
}

// —— 離線估算器 ——
function parsePortion(text) {
  // 嘗試抓數量（幾隻、幾碗、幾片、g/克）
  const mGram = text.match(/(\\d+(?:\\.\\d+)?)\\s*(g|克)/i);
  if (mGram) return { grams: parseFloat(mGram[1]) };
  const mBowl = text.match(/(\\d+(?:\\.\\d+)?)\\s*(碗|bowl)/i);
  if (mBowl) return { grams: parseFloat(mBowl[1]) * 160 }; // 一碗飯約 160g
  const mPieces = text.match(/(\\d+(?:\\.\\d+)?)\\s*(隻|件|塊|片)/);
  if (mPieces) return { pieces: parseFloat(mPieces[1]) };
  return {};
}

function offlineEstimate(text /**: string */) {
  // 將描述拆詞很難，這裡以逗號/頓號/和/同/加 等分隔粗略切開
  const chunks = text
    .replace(/[，、]/g, ",")
    .replace(/(和|同|加|以及|跟)/g, ",")
    .split(",")
    .map(s => s.trim())
    .filter(Boolean);

  const items = [];
  for (const ch of chunks) {
    const base = findFoodMacroByName(ch);
    if (!base) continue;
    const p = parsePortion(ch);
    let grams = p.grams ?? (p.pieces ? p.pieces * (ch.includes("雞蛋") || ch.includes("蛋") ? 50 : 40) : 100);
    if (grams < 1) grams = 100; // 防呆
    const factor = grams / 100;
    items.push({
      name: ch,
      grams: Math.round(grams),
      calories: Math.round(base.kcal * factor),
      protein: +(base.p * factor).toFixed(1),
      fat: +(base.f * factor).toFixed(1),
      carbs: +(base.c * factor).toFixed(1),
    });
  }

  if (!items.length) {
    // 若完全抓不到已知食物，回傳一則 0 記錄以免空白
    return [{ name: text, grams: 0, calories: 0, protein: 0, fat: 0, carbs: 0 }];
  }
  return items;
}

// —— ICS 匯出 ——
function buildICS(entries /**: Entry[] */, title = "飲食紀錄") {
  const escape = (s) => String(s).replace(/\\\\/g, "\\\\\\\\").replace(/\\n/g, "\\\\n").replace(/, /g, ",");
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//DietLog AI//ZH-HK//",
  ];

  for (const e of entries) {
    const dt = new Date(`${e.dateISO}T08:00:00`); // 預設早上 8:00 記一筆（使用者可之後在行事曆移動）
    const dtstamp = dt.toISOString().replace(/[-:]/g, "").replace(/\\..+/, "Z");
    const uidStr = `${e.id}@dietlog.local`;
    const summary = `${e.meal || "飲食"}：${Math.round(e.calories)} kcal，P${Math.round(e.protein)} F${Math.round(e.fat)} C${Math.round(e.carbs)}`;
    const desc = e.items.map(it => `${it.name}${it.grams?` ${it.grams}g`:''} — ${it.calories||0}kcal, P${it.protein||0} F${it.fat||0} C${it.carbs||0}`).join("\\n");
    lines.push(
      "BEGIN:VEVENT",
      `UID:${uidStr}`,
      `DTSTAMP:${dtstamp}`,
      `DTSTART:${dtstamp}`,
      `SUMMARY:${escape(summary)}`,
      `DESCRIPTION:${escape(desc)}`,
      "END:VEVENT"
    );
  }

  lines.push("END:VCALENDAR");
  return lines.join("\\r\\n");
}

function download(filename, content, mime = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  URL.revokeObjectURL(url);
  a.remove();
}

// —— 月曆工具 ——
function getMonthGrid(year, month /* 0-11 */) {
  const first = new Date(year, month, 1);
  const start = new Date(year, month, 1 - ((first.getDay() + 6) % 7)); // 以星期一為起始
  const days = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
    days.push(d);
  }
  return days;
}

function classNames(...xs) { return xs.filter(Boolean).join(" "); }

// —— 主元件 ——
export default function App() {
  const [raw, setRaw] = useState("");
  const [entries, setEntries] = useState(/** @type {Entry[]} */([]));
  const [settings, setSettings] = useState(/** @type {AISettings} */({ provider: "offline" }));
  const [busy, setBusy] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // 今日/月曆狀態
  const today = new Date();
  const [ym, setYM] = useState({ y: today.getFullYear(), m: today.getMonth() });
  const [selectedDateISO, setSelectedDateISO] = useState(todayISO());

  // 讀寫 localStorage
  useEffect(() => {
    try {
      const e = JSON.parse(localStorage.getItem(LS_ENTRIES) || "[]");
      if (Array.isArray(e)) setEntries(e);
    } catch {}
    try {
      const s = JSON.parse(localStorage.getItem(LS_SETTINGS) || "{}");
      if (s && s.provider) setSettings(s);
    } catch {}
  }, []);

  useEffect(() => {
    localStorage.setItem(LS_ENTRIES, JSON.stringify(entries));
  }, [entries]);
  useEffect(() => {
    localStorage.setItem(LS_SETTINGS, JSON.stringify(settings));
  }, [settings]);

  const selectedDate = useMemo(() => new Date(selectedDateISO + "T12:00:00"), [selectedDateISO]);

  const dayEntries = useMemo(() => entries.filter(e => e.dateISO === selectedDateISO).sort((a,b)=>a.createdAt-b.createdAt), [entries, selectedDateISO]);
  const dayTotals = useMemo(() => dayEntries.reduce((a, b) => ({
    calories: a.calories + (b.calories || 0),
    protein: a.protein + (b.protein || 0),
    fat: a.fat + (b.fat || 0),
    carbs: a.carbs + (b.carbs || 0),
  }), { calories: 0, protein: 0, fat: 0, carbs: 0 }), [dayEntries]);

  const monthDays = useMemo(() => getMonthGrid(ym.y, ym.m), [ym]);

  async function handleAnalyze() {
    if (!raw.trim()) return;
    setBusy(true);
    try {
      // 解析日期（相對）
      const maybeDate = parseCantoneseDate(raw);
      const date = maybeDate || selectedDate;

      const result = await analyzeWithAI(settings, raw, date);
      const entry = /** @type {Entry} */({
        id: uid(),
        text: raw.trim(),
        dateISO: result.dateISO,
        meal: result.meal,
        calories: Math.round(result.totals.calories || 0),
        protein: +(result.totals.protein || 0).toFixed(1),
        fat: +(result.totals.fat || 0).toFixed(1),
        carbs: +(result.totals.carbs || 0).toFixed(1),
        items: result.items || [],
        source: result.source,
        createdAt: Date.now(),
      });
      setEntries(prev => [...prev, entry]);
      setRaw("");
      setSelectedDateISO(entry.dateISO);
    } finally {
      setBusy(false);
    }
  }

  function deleteEntry(id) {
    setEntries(prev => prev.filter(e => e.id !== id));
  }

  function exportDayICS() {
    const ics = buildICS(dayEntries, `飲食紀錄-${selectedDateISO}`);
    download(`diet-${selectedDateISO}.ics`, ics, "text/calendar;charset=utf-8");
  }

  function exportMonthICS() {
    const monthISO = `${ym.y}-${pad(ym.m+1)}`;
    const monthEntries = entries.filter(e => e.dateISO.startsWith(monthISO));
    const ics = buildICS(monthEntries, `飲食紀錄-${monthISO}`);
    download(`diet-${monthISO}.ics`, ics, "text/calendar;charset=utf-8");
  }

  function resetAll() {
    if (!confirm("確定要清空所有紀錄？這個動作無法還原。")) return;
    setEntries([]);
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50 text-slate-800">
      <header className="sticky top-0 z-10 backdrop-blur bg-white/70 border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-slate-900 text-white grid place-items-center text-lg font-bold">食</div>
            <div>
              <h1 className="text-xl font-semibold">食記AI</h1>
              <p className="text-xs text-slate-500">自然語言飲食日誌 × AI 營養分析 × 日曆匯出</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={()=>setShowSettings(true)} className="px-3 py-1.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 shadow-sm">設定</button>
            <button onClick={resetAll} className="px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-100">清空</button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 grid lg:grid-cols-5 gap-6">
        {/* 左：輸入與當日清單 */}
        <section className="lg:col-span-3 space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold">快速紀錄</h2>
              <div className="text-xs text-slate-500">選擇日期：
                <input type="date" value={selectedDateISO} onChange={e=>setSelectedDateISO(e.target.value)} className="ml-2 border rounded-lg px-2 py-1 text-xs"/>
              </div>
            </div>

            <textarea
              value={raw}
              onChange={(e)=>setRaw(e.target.value)}
              onKeyDown={(e)=>{
                if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleAnalyze();
              }}
              placeholder={"例子：上星期四食咗三隻雞翼同一碗白飯；今晚食咗350g牛扒加沙律；早餐一個麵包兩隻蛋"}
              className="w-full min-h-[120px] rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-400 px-3 py-2"
            />
            <div className="flex items-center justify-between mt-3">
              <div className="text-xs text-slate-500">提示：按 <kbd className="px-1 border rounded">⌘/Ctrl</kbd> + <kbd className="px-1 border rounded">Enter</kbd> 送出</div>
              <button onClick={handleAnalyze} disabled={busy || !raw.trim()} className={classNames("px-4 py-2 rounded-xl text-white shadow-sm", busy?"bg-slate-400":"bg-slate-900 hover:bg-slate-800")}>{busy?"分析中…":"AI 分析並記錄"}</button>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">{selectedDateISO} 的紀錄</h3>
              <div className="flex items-center gap-2">
                <button onClick={exportDayICS} className="px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-100">匯出當日 ICS</button>
              </div>
            </div>

            {!dayEntries.length && (
              <p className="text-sm text-slate-500">暫無紀錄。可在上方輸入自然語言，例如「上星期四食咗雞翼」。</p>
            )}

            <ul className="space-y-3">
              {dayEntries.map(e => (
                <li key={e.id} className="border border-slate-200 rounded-xl p-3 hover:shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{e.meal}・{e.source === 'AI' ? 'AI' : '離線估算'}</div>
                    <button onClick={()=>deleteEntry(e.id)} className="text-xs text-red-600 hover:underline">刪除</button>
                  </div>
                  <div className="text-sm text-slate-600 mt-1">{e.text}</div>
                  <div className="mt-2 grid sm:grid-cols-4 gap-2 text-sm">
                    <div className="rounded-lg bg-slate-50 p-2 border"><div className="text-xs text-slate-500">熱量</div><div className="text-lg font-semibold">{e.calories} kcal</div></div>
                    <div className="rounded-lg bg-slate-50 p-2 border"><div className="text-xs text-slate-500">蛋白質</div><div className="text-lg font-semibold">{e.protein} g</div></div>
                    <div className="rounded-lg bg-slate-50 p-2 border"><div className="text-xs text-slate-500">脂肪</div><div className="text-lg font-semibold">{e.fat} g</div></div>
                    <div className="rounded-lg bg-slate-50 p-2 border"><div className="text-xs text-slate-500">碳水</div><div className="text-lg font-semibold">{e.carbs} g</div></div>
                  </div>
                  {!!e.items?.length && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-sm text-slate-600">查看項目明細</summary>
                      <div className="overflow-x-auto mt-2">
                        <table className="w-full text-sm border">
                          <thead>
                            <tr className="bg-slate-50 text-left">
                              <th className="p-2 border">食物</th>
                              <th className="p-2 border">克數</th>
                              <th className="p-2 border">熱量</th>
                              <th className="p-2 border">蛋白質</th>
                              <th className="p-2 border">脂肪</th>
                              <th className="p-2 border">碳水</th>
                            </tr>
                          </thead>
                          <tbody>
                            {e.items.map((it, idx) => (
                              <tr key={idx}>
                                <td className="p-2 border whitespace-nowrap">{it.name}</td>
                                <td className="p-2 border">{it.grams ?? "-"}</td>
                                <td className="p-2 border">{it.calories ?? "-"}</td>
                                <td className="p-2 border">{it.protein ?? "-"}</td>
                                <td className="p-2 border">{it.fat ?? "-"}</td>
                                <td className="p-2 border">{it.carbs ?? "-"}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </details>
                  )}
                </li>
              ))}
            </ul>

            {!!dayEntries.length && (
              <div className="mt-4 p-3 rounded-xl bg-slate-900 text-white grid sm:grid-cols-4 gap-2">
                <div>
                  <div className="text-xs text-white/60">當日總熱量</div>
                  <div className="text-2xl font-semibold">{Math.round(dayTotals.calories)} kcal</div>
                </div>
                <div>
                  <div className="text-xs text-white/60">蛋白質</div>
                  <div className="text-2xl font-semibold">{Math.round(dayTotals.protein)} g</div>
                </div>
                <div>
                  <div className="text-xs text-white/60">脂肪</div>
                  <div className="text-2xl font-semibold">{Math.round(dayTotals.fat)} g</div>
                </div>
                <div>
                  <div className="text-xs text-white/60">碳水</div>
                  <div className="text-2xl font-semibold">{Math.round(dayTotals.carbs)} g</div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* 右：月曆 */}
        <aside className="lg:col-span-2 space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">月曆</h3>
              <div className="flex items-center gap-2">
                <button onClick={()=>setYM(v=>({ y: v.m===0? v.y-1 : v.y, m: v.m===0? 11 : v.m-1 }))} className="px-3 py-1.5 rounded-xl border">上一月</button>
                <div className="text-sm font-medium w-32 text-center">{ym.y} 年 {ym.m+1} 月</div>
                <button onClick={()=>setYM(v=>({ y: v.m===11? v.y+1 : v.y, m: v.m===11? 0 : v.m+1 }))} className="px-3 py-1.5 rounded-xl border">下一月</button>
              </div>
            </div>

            <div className="grid grid-cols-7 gap-2 text-xs mb-2 text-slate-500">
              {['一','二','三','四','五','六','日'].map(d=> <div key={d} className="text-center">週{d}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-2">
              {monthDays.map((d, i)=>{
                const iso = toDateISO(d);
                const inMonth = d.getMonth() === ym.m;
                const list = entries.filter(e => e.dateISO === iso);
                const kcal = list.reduce((a,b)=> a + (b.calories||0), 0);
                const isSel = iso === selectedDateISO;
                return (
                  <button key={i} onClick={()=>setSelectedDateISO(iso)} className={classNames("rounded-xl p-2 border text-left hover:shadow-sm", inMonth?"bg-white":"bg-slate-50 text-slate-400", isSel && "ring-2 ring-slate-900")}>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium">{d.getDate()}</div>
                      {!!kcal && <div className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 text-white">{Math.round(kcal)} kcal</div>}
                    </div>
                    <div className="mt-1 space-y-1">
                      {list.slice(0,3).map(e=> (
                        <div key={e.id} className="text-[11px] truncate text-slate-600">{e.meal}・{e.calories} kcal</div>
                      ))}
                      {list.length > 3 && <div className="text-[10px] text-slate-400">… 另有 {list.length-3} 筆</div>}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="mt-3 flex items-center justify-between">
              <button onClick={()=>{ setYM({ y: today.getFullYear(), m: today.getMonth() }); setSelectedDateISO(todayISO()); }} className="px-3 py-1.5 rounded-xl border">回到今日</button>
              <button onClick={exportMonthICS} className="px-3 py-1.5 rounded-xl border">匯出本月 ICS</button>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-4">
            <h3 className="font-semibold mb-2">使用小貼士</h3>
            <ul className="list-disc pl-5 text-sm text-slate-600 space-y-1">
              <li>可用口語：例如「<span className="font-medium">上星期四食咗三隻雞翼同一碗白飯</span>」。會自動寫入「上星期四」的日期。</li>
              <li>如要指定克數：打「<span className="font-medium">牛扒 350g</span>」。</li>
              <li>未設定 API Key 時，系統使用離線估算（較粗略）。設定好 API 後準確度更高。</li>
              <li>可把每日或整月紀錄匯出成 <span className="font-mono">.ics</span>，加入你常用的行事曆。</li>
            </ul>
          </div>
        </aside>
      </main>

      {/* 設定對話框 */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/30 grid place-items-center p-4" onClick={()=>setShowSettings(false)}>
          <div className="max-w-lg w-full rounded-2xl bg-white p-5 shadow-xl" onClick={e=>e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-lg font-semibold">AI / 系統設定</h3>
              <button onClick={()=>setShowSettings(false)} className="text-slate-500 hover:text-slate-700">✕</button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1">模式</label>
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <button onClick={()=>setSettings(s=>({ ...s, provider: "offline" }))} className={classNames("px-3 py-2 rounded-xl border", settings.provider==='offline' && 'bg-slate-900 text-white')}>離線估算</button>
                  <button onClick={()=>setSettings(s=>({ ...s, provider: "openai", baseUrl: "https://api.openai.com/v1" }))} className={classNames("px-3 py-2 rounded-xl border", settings.provider==='openai' && 'bg-slate-900 text-white')}>OpenAI 官方</button>
                  <button onClick={()=>setSettings(s=>({ ...s, provider: "compatible" }))} className={classNames("px-3 py-2 rounded-xl border", settings.provider==='compatible' && 'bg-slate-900 text-white')}>OpenAI 兼容</button>
                </div>
                <p className="text-xs text-slate-500 mt-1">* 兼容模式可用於 DeepSeek / DeepInfra 等 OpenAI 介面相容供應商（填入 Base URL + Model）。</p>
              </div>

              {settings.provider !== 'offline' && (
                <>
                  <div>
                    <label className="block text-sm font-medium mb-1">API Key</label>
                    <input type="password" placeholder="sk-..." value={settings.apiKey||''} onChange={e=>setSettings(s=>({ ...s, apiKey: e.target.value }))} className="w-full border rounded-xl px-3 py-2"/>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium mb-1">Base URL</label>
                      <input type="text" placeholder="https://api.openai.com/v1" value={settings.baseUrl||''} onChange={e=>setSettings(s=>({ ...s, baseUrl: e.target.value }))} className="w-full border rounded-xl px-3 py-2"/>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Model</label>
                      <input type="text" placeholder="gpt-4o-mini / deepseek-chat / ..." value={settings.model||''} onChange={e=>setSettings(s=>({ ...s, model: e.target.value }))} className="w-full border rounded-xl px-3 py-2"/>
                    </div>
                  </div>

                  {settings.provider==='openai' && (
                    <div>
                      <label className="block text-sm font-medium mb-1">OpenAI Organization（可選）</label>
                      <input type="text" placeholder="org_...（如有）" value={settings.organization||''} onChange={e=>setSettings(s=>({ ...s, organization: e.target.value }))} className="w-full border rounded-xl px-3 py-2"/>
                    </div>
                  )}
                </>
              )}

              <div className="pt-2 flex items-center justify-between">
                <div className="text-xs text-slate-500">資料僅儲存於你的瀏覽器。可隨時在「清空」移除。</div>
                <button onClick={()=>setShowSettings(false)} className="px-4 py-2 rounded-xl bg-slate-900 text-white">完成</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <footer className="py-8 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} 食記AI — 自然語言飲食日誌。此頁面僅供個人紀錄與估算參考，實際營養以專業標示為準。
      </footer>
    </div>
  );
}
