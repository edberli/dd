export default { base: '/dietlog-ai/' }
